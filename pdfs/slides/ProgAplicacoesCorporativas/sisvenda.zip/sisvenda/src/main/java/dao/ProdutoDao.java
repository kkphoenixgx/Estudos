package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Produto;

public class ProdutoDao {
	
	private Connection con;
	
	public ProdutoDao() {
		con = ConnectionFactory.getConnection();
	}
	
	public void inserir(Produto produto) throws SQLException {
		String sql = "insert into produto(nome, valor, idcategoria) "
				+ " values(?,?,?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,produto.getNome());
		stmt.setFloat(2, produto.getValor());
		stmt.setInt(3, produto.getCategoria().getId());
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	public void alterar(Produto produto) throws SQLException {
		String sql = "update produto "
				+ " set nome = ?,  valor = ?, idcategoria = ? "
				+ " where id = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,produto.getNome());
		stmt.setFloat(2, produto.getValor());
		stmt.setInt(3, produto.getCategoria().getId());
		stmt.setInt(4, produto.getId());
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	public List<Produto> listar(String nome) throws SQLException{
		String sql = "select id, nome, valor, idcategoria "
				+ " from produto where nome like ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		nome ="%" + nome + "%";
		stmt.setString(1,nome);
		ResultSet rs = stmt.executeQuery();
		
		List<Produto> produtos = new ArrayList<Produto>();

		Produto produto = null;
		CategoriaDao catDao = null;
		while (rs.next()) {
			catDao = new CategoriaDao();
			produto = new Produto();
			produto.setId(rs.getInt("id"));
			produto.setNome(rs.getString("nome"));
			produto.setValor(rs.getFloat("valor"));
			produto.setCategoria(catDao.listarUm(rs.getInt("idcategoria")));
			produtos.add(produto);
		}
		stmt.close();
		con.close();
		return produtos;
	}
	
	public void excluir(int id) throws SQLException {
		String sql = "delete from produto where id = ? ";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,id);
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	
	
	public Produto listarUm(int id) throws SQLException{
		String sql = "select id, nome, valor, idcategoria "
				+ " from produto where id = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,id);
		ResultSet rs = stmt.executeQuery();

		Produto produto = null;
		CategoriaDao catDao = null;
		if (rs.next()) {
			catDao = new CategoriaDao();
			produto = new Produto();
			produto.setId(rs.getInt("id"));
			produto.setNome(rs.getString("nome"));
			produto.setValor(rs.getFloat("valor"));
			produto.setCategoria(catDao.listarUm(rs.getInt("idcategoria")));
		}
		stmt.close();
		con.close();
		return produto;
	}

}

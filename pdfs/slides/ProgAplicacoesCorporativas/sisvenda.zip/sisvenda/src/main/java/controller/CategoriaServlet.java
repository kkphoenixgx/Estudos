package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import dao.CategoriaDao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Categoria;

@WebServlet("/categorias")
public class CategoriaServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Extrair o nome
        String nome = request.getParameter("nome");

        // Instaciar uma categoira e o CategoriaDAO
        Categoria categoria = new Categoria();
        CategoriaDao catDao = new CategoriaDao();

        // Atribuir o nome
        categoria.setNome(nome);

        // Inserir uma Categoria
        try {
            catDao.inserir(categoria);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Extrai o destino, ou seja, a página do despacho        
        String next = request.getParameter("next");
        //Instancia uma categoriaDao;
        CategoriaDao catDao = new CategoriaDao();
        // Cria uma lista de categorias
        List<Categoria> categorias = null;
        // Buscar no Banco todas as categorias
        try {
            categorias = catDao.listarTodos();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //Despachar Categorias
        request.setAttribute("categorias", categorias);
        RequestDispatcher rd = request.getRequestDispatcher(next);
        rd.forward(request, response);
    }

}

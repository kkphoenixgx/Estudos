package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Categoria;

public class CategoriaDao {

	private Connection con;
	
	public CategoriaDao() {
		con = ConnectionFactory.getConnection();
	}
	
	public void inserir(Categoria categoria) throws SQLException {
		String sql = "insert into categoria(nome) values(?)";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,categoria.getNome());
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	public void apagar(Categoria categoria) throws SQLException {
		String sql = "delete from categoria where id = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1,categoria.getId());
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	public void alterar(Categoria categoria) throws SQLException {
		String sql = "update categoria set nome = ? where id = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setString(1,categoria.getNome());
		stmt.setInt(2,categoria.getId());
		stmt.execute();
		stmt.close();
		con.close();
	}
	
	public Categoria listarUm(int id) throws SQLException{
		String sql = "select id, nome from categoria where id = ?";
		PreparedStatement stmt = con.prepareStatement(sql);
		stmt.setInt(1, id);
		
		ResultSet rs = stmt.executeQuery();
		
		Categoria categoria = null;
		if (rs.next()) {
			categoria = new Categoria();
			categoria.setId(rs.getInt("id"));
			categoria.setNome(rs.getString("nome"));
		}
		stmt.close();
		con.close();
		return categoria;
	}
	
	public List<Categoria> listarTodos() throws SQLException{
		String sql = "select id, nome from categoria";
		PreparedStatement stmt = con.prepareStatement(sql);
		
		ResultSet rs = stmt.executeQuery();
		
		List<Categoria> categorias = new ArrayList<Categoria>();

		Categoria categoria = null;
		while (rs.next()) {
			categoria = new Categoria();
			categoria.setId(rs.getInt("id"));
			categoria.setNome(rs.getString("nome"));
			categorias.add(categoria);
		}
		stmt.close();
		con.close();
		return categorias;
	}
	
	
}
